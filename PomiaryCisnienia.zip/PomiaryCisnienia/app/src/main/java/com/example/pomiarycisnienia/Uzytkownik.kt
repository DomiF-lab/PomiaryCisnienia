package com.example.pomiarycisnienia

// Klasa reprezentująca dane użytkownika
data class Uzytkownik(
    var mail: String = "",
    var imie: String = ""
)
